<h1 align="center">Ultimate Menu</h1>

<h1 align="center">For Original thread you can find it here====> https://www.unknowncheats.me/forum/grand-theft-auto-v/565688-1-64-ultimate-unlocker.html</h1>

# How To Use Ultimate Menu Script
For every Version of the ultimate menu (Kiddion/YimMenu) there is a different use and ways to fully Run It. 

For Kiddions script is just puting the script into scripts directory, inside the Kiddions files.

For YimMenu it is actually the same way, but first before initiating the script you will need to go to Settings > Lua > Open Folder Option 

From There Go To Scripts Folder Then Paste The Ultimate Menu In There


--------------------------------------------------------------------------------------------------

## Gta V Scripts 
Im presenting you some Gta V Scripts for online or campaign, these are made by me so if you find an error please dm to discord. (@l7neg)

--------------------------------------------------------------------------------------------------
## Questions And Answers: 

1: How Do I Install Kiddions Modest Menu?
A: Answered in https://sub.l7neg.tk/discord

2- Why Ultimate Menu Script Not Showing Up In Kiddions?
A: Make Sure Ultimate Menu.lua Script Is In Kiddions Scrips Folder

3- How To Do The 6 Mil Crates Method? 
A: Answered in https://sub.l7neg.tk/discord

4- What Are The Limits And The Best 5 Ways To Make Money In Gta Online?
A: Answered in https://sub.l7neg.tk/discord
---------------------------------------------------------------------------------------------------

- Meaning Emojis:
🟢 Undetected
🟠 Working on / In Progress / In Testing Stage
🔴 Detected

--------------------------------------------------------------------------------------------------
No ETA for big updates also because i don't know actually if im going to be able to continue this script (boths) because i have a life and i need to study. This is a helpfull and fun project for everyone who wants to use it, is free and you can use my script has a template.

## About
-  By the way to anyone who ask's about the Ultimate-Menu script, is not entire mine, there is actually in credits every single person who i taked code from and who helped me with this.
## Latest Ultimate Menu Kiddions update was on: 7/05/2023
## Latest Ultimate Menu Stand update was on: 24/07/2023
